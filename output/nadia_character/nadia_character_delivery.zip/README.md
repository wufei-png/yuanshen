# 娜蒂娅「两衡之间」交付包

这是一个面向阅读和赠礼的原创同人角色档案原型。

## 打开方式

- 直接双击 `index.html`，无需联网；
- A5 角色档案 PDF 已放在 `print/` 目录；
- `assets/` 保存角色主视觉和日常插画。
- `nadia_character_delivery.zip` 是不含内部审阅稿和失败草稿的赠礼版压缩包。

## 内容边界

成品将娜蒂娅作为独立的二次元原创角色呈现，不解释现实人物映射，也不把原始照片放进玩家版内容。原始母设定仍在项目 `docs/` 目录中。

## 当前资产状态

- `assets/nadia_splash.png`：二次元游戏角色宣传立绘；
- `assets/nadia_daily.png`：二次元日常插画；
- `assets/nadia_splash_v1_semi_realistic.png`：早期半写实草稿，仅供追溯，不纳入成品；
- `assets/nadia_daily_v1_semi_realistic.png`：早期半写实草稿，仅供追溯，不纳入成品；
- `assets/nadia_acrylic_cutout_v1_checkerboard.png`：透明底失败预览，不可用于印厂。

## 免责声明

本文档是基于《原神》世界观语汇的原创同人创作，不代表官方资料。7.0 相关术语和角色生态以制作时的版本基线记录为准。
